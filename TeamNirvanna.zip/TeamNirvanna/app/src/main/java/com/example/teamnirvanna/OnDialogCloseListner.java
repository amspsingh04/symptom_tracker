package com.example.teamnirvanna;

import android.content.DialogInterface;

public interface OnDialogCloseListner {

    void onDialogClose(DialogInterface dialogInterface);
}
