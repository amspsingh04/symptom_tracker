package com.example.teamnirvanna;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import com.google.android.material.timepicker.TimeFormat;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class MainPage extends AppCompatActivity {

    private Button button;

    List<String> symptomList;
    ArrayAdapter<String> arrayAdapter;
    ListView listView;
    EditText editText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_page);

        button = findViewById(R.id.gethelpbutton);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openHelpActivity();
            }
        });

        Calendar calendar = Calendar.getInstance();
        String currentDate = DateFormat.getDateInstance().format(calendar.getTime());

        symptomList = new ArrayList<>();
        arrayAdapter = new ArrayAdapter<>(this,R.layout.list_view_layout,symptomList);
        listView = findViewById(R.id.id_list_view);

        listView.setAdapter(arrayAdapter);
        editText = findViewById(R.id.id_edit_text);

        Intent intent = getIntent();
        String message = intent.getStringExtra(MainActivity.welcome);
        TextView textView = findViewById(R.id.nameview);
        textView.setText(message);
    }

    public void addSymptomtoList(View view){

        Calendar calendar = Calendar.getInstance();
        Date calendar1 = Calendar.getInstance().getTime();
        String currrentTime = calendar1.toString();
        String currentDate = DateFormat.getDateInstance(DateFormat.SHORT).format(calendar.getTime());

        String a = editText.getText().toString();
        String b = a+" "+currrentTime;
        symptomList.add(b);
        arrayAdapter.notifyDataSetChanged();

        editText.setText("");
    }

    public void openHelpActivity(){
        Intent intent = new Intent(this,HelpActivity.class);
        startActivity(intent);
    }
}